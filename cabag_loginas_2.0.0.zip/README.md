cabag_loginas
=============

Friendly fork of current TER version without support for TYPO3 CMS 6.2+ and with improved styling.

* Within the backend you have a button in the fe_user table to quickly login as this fe user in frontend.
* If you have a frontend user with the same email adress as your backend user you get an icon in the top toolbar menu.
* If you have several fe_user accounts with the same email address you get the all shown.
* You can configure the information displayed with the icon in the EM.

You may provide pull requests if you think that anything can be improved.