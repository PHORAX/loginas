#
# Table structure for table 'sys_domain'
#
CREATE TABLE sys_domain (
	tx_cabagfileexplorer_redirect_to tinytext,
);

#
# Table structure for table 'fe_users'
#
CREATE TABLE fe_users (
	tx_cabagloginas_loginas tinytext,
);
